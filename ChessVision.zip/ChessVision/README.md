# Chess Vision (Faz 2)

Android satranç analiz uygulaması. **Bu sürümde çalışanlar:** Stockfish motoru, FEN doğrulama,
analiz ekranı (en iyi hamle, değerlendirme çubuğu, derinlik, süre, devam varyantı).

**Henüz yok (sonraki aşamalar):** ekran yakalama (Faz 3), görüntüden tahta/taş tanıma (Faz 4),
10 saniyelik otomatik yenileme (Faz 5).

## APK'yı telefondan derlemek (GitHub Actions)
1. GitHub'da yeni bir depo (repository) aç.
2. Bu ZIP'i (`ChessVision.zip`) depoya yükle: *Add file → Upload files*.
3. `.github/workflows/build-apk.yml` adlı yeni bir dosya oluşturup `build-apk.yml` içeriğini yapıştır.
4. *Actions* sekmesinde "APK derle" çalışır (yaklaşık 5–10 dk). Bitince "ChessVision-debug-apk" dosyasını indir.
5. APK'yı telefonda aç (bilinmeyen kaynaklardan kuruluma izin gerekir).

## Bilgisayarda derlemek
Android Studio ile aç. Önce `app/src/main/jniLibs/arm64-v8a/libstockfish.so` dosyasını koy
(Stockfish 19 Android arm64 sürümünün çalıştırılabilir dosyası; adı değiştirilerek):
https://github.com/official-stockfish/Stockfish/releases/tag/sf_19 → `stockfish-android-arm64-universal`.

## Testler
`app/src/test/...` — FEN doğrulama, UCI ayrıştırma, puan yönü (beyaz/siyah) ve gerçek motor testleri.
Motor testleri için `STOCKFISH_BIN` ortam değişkeni bilgisayardaki bir Stockfish dosyasını göstermeli;
tanımlı değilse motor testleri atlanır.
