package com.chessvision.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.chessvision.app.chess.Fen
import com.chessvision.app.chess.FenResult
import com.chessvision.app.chess.Position
import com.chessvision.app.engine.Eval
import java.util.Locale

@Composable
fun AnalysisScreen(vm: AnalysisViewModel = viewModel()) {
    val s by vm.state.collectAsState()
    val parsed = remember(s.fenInput) { Fen.parse(s.fenInput) }
    val position = (parsed as? FenResult.Valid)?.position

    val result = s.result
    val bestMove: String? = result?.bestMove ?: s.live?.moves?.firstOrNull()
    val eval: Eval? = result?.lines?.firstOrNull()?.eval ?: s.live?.eval
    val highlight = bestMove?.let { moveSquares(it) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Palette.Bg)
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Chess Vision", color = Palette.Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Faz 2 · FEN konumunu Stockfish ile analiz et", color = Palette.TextDim, fontSize = 13.sp)

        EngineCard(s)

        if (eval != null) EvalBar(eval)
        BoardView(position = position, whiteAtBottom = s.whiteAtBottom, highlight = highlight)

        ResultCard(s)

        FenCard(
            fen = s.fenInput,
            error = s.fenError ?: (parsed as? FenResult.Invalid)?.reason,
            enabled = !s.analyzing,
            onChange = vm::setFen,
            onReset = { vm.setFen(Fen.START) },
        )

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = vm::analyze,
                enabled = s.engineStatus == EngineStatus.READY && !s.analyzing && position != null,
                colors = ButtonDefaults.buttonColors(containerColor = Palette.Blue),
                modifier = Modifier.weight(1f),
            ) { Text("Analiz et") }
            OutlinedButton(
                onClick = vm::stop,
                enabled = s.analyzing,
                modifier = Modifier.weight(1f),
            ) { Text("Durdur") }
        }

        SettingsCard(
            moveTimeMs = s.moveTimeMs,
            whiteAtBottom = s.whiteAtBottom,
            onMoveTime = vm::setMoveTime,
            onWhiteAtBottom = vm::setWhiteAtBottom,
        )

        Text(
            "Ekran yakalama ve tahtayı görüntüden tanıma sonraki aşamalarda eklenecek. " +
                "Şu an konumu elle (FEN) girerek analiz edebilirsiniz.",
            color = Palette.TextDim,
            fontSize = 12.sp,
        )
    }
}

@Composable
private fun CardBox(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Palette.Surface),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { content() }
    }
}

@Composable
private fun EngineCard(s: AnalysisUiState) {
    val (color, title) = when (s.engineStatus) {
        EngineStatus.STARTING -> Palette.Orange to "Motor başlatılıyor… (ilk açılış biraz sürebilir)"
        EngineStatus.READY -> Palette.Green to "Stockfish motoru hazır"
        EngineStatus.ERROR -> Palette.Red to "Motor başlatılamadı"
    }
    CardBox {
        Text(title, color = color, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        if (s.engineStatus == EngineStatus.STARTING) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Palette.Blue)
        }
        s.engineMessage?.let { Text(it, color = Palette.TextDim, fontSize = 13.sp) }
    }
}

@Composable
private fun EvalBar(eval: Eval) {
    val frac = eval.whiteFraction().coerceIn(0.03f, 0.97f)
    val advantage = when {
        eval.checkmatedSide != null || eval.mateIn != null -> true
        else -> kotlin.math.abs(eval.centipawns ?: 0) >= 50
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(14.dp)
                .clip(RoundedCornerShape(7.dp)),
        ) {
            Box(Modifier.weight(frac).fillMaxHeight().background(Color.White))
            Box(Modifier.weight(1f - frac).fillMaxHeight().background(Color(0xFF05080F)))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Beyaz", color = Palette.TextDim, fontSize = 12.sp)
            Text(
                eval.label(),
                color = if (advantage) Palette.Green else Palette.Text,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
            )
            Text("Siyah", color = Palette.TextDim, fontSize = 12.sp)
        }
    }
}

@Composable
private fun BoardView(position: Position?, whiteAtBottom: Boolean, highlight: Pair<Int, Int>?) {
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp)),
    ) {
        val pieceSize = ((maxWidth / 8).value * 0.78f).sp
        Column(Modifier.fillMaxSize()) {
            for (row in 0 until 8) {
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    for (col in 0 until 8) {
                        val r = if (whiteAtBottom) row else 7 - row
                        val c = if (whiteAtBottom) col else 7 - col
                        val idx = r * 8 + c
                        val dark = (r + c) % 2 == 1
                        val hl = highlight != null && (idx == highlight.first || idx == highlight.second)
                        val bg = when {
                            dark && hl -> Palette.SquareDarkHl
                            dark -> Palette.SquareDark
                            hl -> Palette.SquareLightHl
                            else -> Palette.SquareLight
                        }
                        Box(
                            Modifier.weight(1f).fillMaxHeight().background(bg),
                            contentAlignment = Alignment.Center,
                        ) {
                            val piece = position?.squares?.get(idx) ?: Position.EMPTY
                            if (piece != Position.EMPTY) {
                                Text(
                                    text = glyph(piece),
                                    fontSize = pieceSize,
                                    color = if (piece.isUpperCase()) Color.White else Color(0xFF0B1220),
                                    style = TextStyle(
                                        shadow = Shadow(Color.Black.copy(alpha = 0.7f), Offset(0f, 0f), 5f),
                                    ),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultCard(s: AnalysisUiState) {
    val result = s.result
    val line = result?.lines?.firstOrNull() ?: s.live
    val bestMove = result?.bestMove ?: s.live?.moves?.firstOrNull()

    CardBox {
        Text("Analiz sonucu", color = Palette.TextDim, fontSize = 12.sp)
        s.analysisError?.let { Text(it, color = Palette.Red, fontSize = 14.sp) }

        if (s.analyzing) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Palette.Blue)
            Text(
                "Analiz sürüyor" + (line?.let { " · derinlik ${it.depth}" } ?: ""),
                color = Palette.Orange,
                fontSize = 13.sp,
            )
        }

        if (line == null && !s.analyzing) {
            if (s.analysisError == null) {
                Text("Henüz analiz yapılmadı.", color = Palette.TextDim, fontSize = 14.sp)
            }
            return@CardBox
        }

        if (line != null) {
            Text(
                text = when {
                    bestMove != null -> formatMove(bestMove)
                    result != null -> "Oynanacak hamle yok"
                    else -> "…"
                },
                color = Palette.Text,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
            )
            Text(line.eval.description(), color = Palette.Text, fontSize = 14.sp)
            val facts = buildList {
                add("Derinlik: ${line.depth}")
                result?.let { add("Süre: ${String.format(Locale.US, "%.1f", it.elapsedMs / 1000.0)} sn") }
                line.nps?.let { add("${it / 1000} bin düğüm/sn") }
            }
            Text(facts.joinToString(" · "), color = Palette.TextDim, fontSize = 13.sp)
            if (line.moves.isNotEmpty()) {
                Text(
                    "Devam: " + line.moves.take(10).joinToString(" "),
                    color = Palette.TextDim,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                )
            }
        }
        if (result?.stoppedEarly == true) {
            Text("Analiz erken durduruldu; sonuç o ana kadarki en iyisidir.", color = Palette.Orange, fontSize = 12.sp)
        }
    }
}

@Composable
private fun FenCard(fen: String, error: String?, enabled: Boolean, onChange: (String) -> Unit, onReset: () -> Unit) {
    CardBox {
        OutlinedTextField(
            value = fen,
            onValueChange = onChange,
            enabled = enabled,
            label = { Text("FEN") },
            isError = error != null,
            supportingText = { if (error != null) Text(error, color = Palette.Red) },
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
            minLines = 2,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedButton(onClick = onReset, enabled = enabled) { Text("Başlangıç konumu") }
    }
}

@Composable
private fun SettingsCard(
    moveTimeMs: Long,
    whiteAtBottom: Boolean,
    onMoveTime: (Long) -> Unit,
    onWhiteAtBottom: (Boolean) -> Unit,
) {
    CardBox {
        Text("Ayarlar", color = Palette.TextDim, fontSize = 12.sp)
        Text("Analiz süresi", color = Palette.Text, fontSize = 14.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (ms in listOf(1_000L, 3_000L, 5_000L, 10_000L)) {
                FilterChip(
                    selected = moveTimeMs == ms,
                    onClick = { onMoveTime(ms) },
                    label = { Text("${ms / 1000} sn") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Palette.Blue,
                        selectedLabelColor = Color.White,
                    ),
                )
            }
        }
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Beyaz altta", color = Palette.Text, fontSize = 14.sp)
            Switch(checked = whiteAtBottom, onCheckedChange = onWhiteAtBottom)
        }
    }
}

private fun glyph(piece: Char): String {
    val base = when (piece.lowercaseChar()) {
        'k' -> "\u265A"
        'q' -> "\u265B"
        'r' -> "\u265C"
        'b' -> "\u265D"
        'n' -> "\u265E"
        else -> "\u265F"
    }
    return base + "\uFE0E" // metin biçimi (emoji değil)
}

private fun moveSquares(uci: String): Pair<Int, Int>? {
    if (uci.length < 4) return null
    val a = Fen.squareIndex(uci.substring(0, 2))
    val b = Fen.squareIndex(uci.substring(2, 4))
    return if (a >= 0 && b >= 0) a to b else null
}

private fun formatMove(uci: String): String {
    if (uci.length < 4) return uci
    val promo = if (uci.length >= 5) " (${uci[4].uppercaseChar()})" else ""
    return "${uci.substring(0, 2)} → ${uci.substring(2, 4)}$promo"
}
