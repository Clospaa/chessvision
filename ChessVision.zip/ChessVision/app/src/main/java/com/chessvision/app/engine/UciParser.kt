package com.chessvision.app.engine

import com.chessvision.app.chess.Side
import java.util.Locale
import kotlin.math.abs
import kotlin.math.exp

/** Stockfish'in bildirdiği puan: HER ZAMAN sırası gelen tarafın açısından. */
sealed interface Score {
    data class Cp(val centipawns: Int) : Score
    data class Mate(val moves: Int) : Score
}

data class InfoLine(
    val depth: Int,
    val multiPv: Int,
    val score: Score,
    /** false: "lowerbound"/"upperbound" ara sonucu; ekranda gösterilmemeli. */
    val exact: Boolean,
    val timeMs: Long?,
    val nodes: Long?,
    val nps: Long?,
    val pv: List<String>,
)

data class BestMove(val move: String?, val ponder: String?)

object UciParser {
    fun parseInfo(line: String): InfoLine? {
        val t = line.trim().split(Regex("\\s+"))
        if (t.isEmpty() || t[0] != "info") return null
        if (t.size > 1 && t[1] == "string") return null

        var depth: Int? = null
        var multiPv = 1
        var score: Score? = null
        var exact = true
        var time: Long? = null
        var nodes: Long? = null
        var nps: Long? = null
        var pv: List<String> = emptyList()

        var i = 1
        while (i < t.size) {
            when (t[i]) {
                "depth" -> { depth = t.getOrNull(i + 1)?.toIntOrNull(); i += 2 }
                "multipv" -> { multiPv = t.getOrNull(i + 1)?.toIntOrNull() ?: 1; i += 2 }
                "time" -> { time = t.getOrNull(i + 1)?.toLongOrNull(); i += 2 }
                "nodes" -> { nodes = t.getOrNull(i + 1)?.toLongOrNull(); i += 2 }
                "nps" -> { nps = t.getOrNull(i + 1)?.toLongOrNull(); i += 2 }
                "score" -> {
                    val kind = t.getOrNull(i + 1)
                    val v = t.getOrNull(i + 2)?.toIntOrNull()
                    if (v != null) {
                        score = when (kind) {
                            "cp" -> Score.Cp(v)
                            "mate" -> Score.Mate(v)
                            else -> null
                        }
                    }
                    i += 3
                    val bound = t.getOrNull(i)
                    if (bound == "lowerbound" || bound == "upperbound") { exact = false; i++ }
                }
                "pv" -> { pv = t.subList(i + 1, t.size); i = t.size }
                else -> i++
            }
        }
        if (depth == null || score == null) return null
        return InfoLine(depth, multiPv, score, exact, time, nodes, nps, pv)
    }

    fun parseBestMove(line: String): BestMove? {
        val t = line.trim().split(Regex("\\s+"))
        if (t.size < 2 || t[0] != "bestmove") return null
        val move = if (t[1] == "(none)" || t[1] == "0000") null else t[1]
        val ponderIdx = t.indexOf("ponder")
        val ponder = if (ponderIdx >= 0) t.getOrNull(ponderIdx + 1) else null
        return BestMove(move, ponder)
    }
}

/** Beyaz açısından değerlendirme. Mat ile piyon avantajı ayrı tutulur. */
data class Eval(
    /** Beyaz açısından 1/100 piyon; mat durumunda null. */
    val centipawns: Int?,
    /** Beyaz açısından mat: >0 beyaz mat ediyor, <0 siyah mat ediyor; yoksa null. */
    val mateIn: Int?,
    /** Konum zaten mat ise mat olan taraf. */
    val checkmatedSide: Side?,
) {
    fun label(): String = when {
        checkmatedSide != null -> "Mat"
        mateIn != null -> if (mateIn > 0) "+M$mateIn" else "-M${abs(mateIn)}"
        else -> String.format(Locale.US, "%+.2f", (centipawns ?: 0) / 100.0)
    }

    fun description(): String = when {
        checkmatedSide != null ->
            "${if (checkmatedSide == Side.WHITE) "Siyah" else "Beyaz"} kazandı: ${if (checkmatedSide == Side.WHITE) "Beyaz" else "Siyah"} mat edildi."
        mateIn != null ->
            if (mateIn > 0) "Beyaz $mateIn hamlede mat ediyor." else "Siyah ${abs(mateIn)} hamlede mat ediyor."
        (centipawns ?: 0) >= 30 -> "Beyaz avantajlı."
        (centipawns ?: 0) <= -30 -> "Siyah avantajlı."
        else -> "Konum dengeli."
    }

    /** Değerlendirme çubuğu için beyazın payı (0..1). */
    fun whiteFraction(): Float = when {
        checkmatedSide != null -> if (checkmatedSide == Side.WHITE) 0f else 1f
        mateIn != null -> if (mateIn > 0) 1f else 0f
        else -> (1.0 / (1.0 + exp(-(centipawns ?: 0) / 400.0))).toFloat()
    }
}

/** UCI puanı sırası gelen tarafın açısından gelir; burada beyaz açısına çevrilir. */
fun Score.toWhiteEval(sideToMove: Side): Eval {
    val sign = if (sideToMove == Side.WHITE) 1 else -1
    return when (this) {
        is Score.Cp -> Eval(centipawns * sign, null, null)
        is Score.Mate ->
            if (moves == 0) Eval(null, null, sideToMove)
            else Eval(null, moves * sign, null)
    }
}
