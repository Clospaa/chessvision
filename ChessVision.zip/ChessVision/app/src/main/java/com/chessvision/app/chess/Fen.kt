package com.chessvision.app.chess

enum class Side {
    WHITE, BLACK;

    val other: Side get() = if (this == WHITE) BLACK else WHITE
}

/** Tahta dizilimi: indeks 0 = a8, 7 = h8, 56 = a1, 63 = h1 (FEN sırası). Boş kare = ' '. */
class Position(
    val squares: CharArray,
    val sideToMove: Side,
    val castling: String,
    val enPassant: String,
    val halfmoveClock: Int,
    val fullmoveNumber: Int,
) {
    fun toFen(): String {
        val sb = StringBuilder()
        for (r in 0 until 8) {
            var empty = 0
            for (f in 0 until 8) {
                val c = squares[r * 8 + f]
                if (c == EMPTY) {
                    empty++
                } else {
                    if (empty > 0) { sb.append(empty); empty = 0 }
                    sb.append(c)
                }
            }
            if (empty > 0) sb.append(empty)
            if (r < 7) sb.append('/')
        }
        sb.append(' ').append(if (sideToMove == Side.WHITE) 'w' else 'b')
        sb.append(' ').append(castling).append(' ').append(enPassant)
        sb.append(' ').append(halfmoveClock).append(' ').append(fullmoveNumber)
        return sb.toString()
    }

    companion object {
        const val EMPTY = ' '
    }
}

sealed interface FenResult {
    data class Valid(val position: Position) : FenResult
    data class Invalid(val reason: String) : FenResult
}

object Fen {
    const val START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

    private val ROOK_DIRS = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))
    private val BISHOP_DIRS = arrayOf(intArrayOf(1, 1), intArrayOf(1, -1), intArrayOf(-1, 1), intArrayOf(-1, -1))
    private val KNIGHT_JUMPS = arrayOf(
        intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(-1, 2), intArrayOf(-2, 1),
        intArrayOf(1, -2), intArrayOf(2, -1), intArrayOf(-1, -2), intArrayOf(-2, -1),
    )

    /** "e4" -> indeks. Geçersizse -1. */
    fun squareIndex(name: String): Int {
        if (name.length != 2) return -1
        val file = name[0] - 'a'
        val rank = name[1] - '0'
        if (file !in 0..7 || rank !in 1..8) return -1
        return (8 - rank) * 8 + file
    }

    fun squareName(index: Int): String = "${'a' + index % 8}${'8' - index / 8}"

    fun parse(text: String): FenResult {
        val parts = text.trim().split(Regex("\\s+"))
        if (parts.size !in 4..6) {
            return FenResult.Invalid("FEN 4 ile 6 alan içermelidir (bulunan: ${if (text.isBlank()) 0 else parts.size}).")
        }

        // 1) Taş dizilimi
        val ranks = parts[0].split('/')
        if (ranks.size != 8) return FenResult.Invalid("Tahta 8 sıradan oluşmalı (bulunan: ${ranks.size}).")
        val sq = CharArray(64) { Position.EMPTY }
        for ((r, rank) in ranks.withIndex()) {
            val rankNo = 8 - r
            var file = 0
            var prevDigit = false
            for (ch in rank) {
                if (ch in '1'..'8') {
                    if (prevDigit) return FenResult.Invalid("$rankNo. sırada art arda rakam var.")
                    file += ch - '0'
                    prevDigit = true
                } else if (ch in "pnbrqkPNBRQK") {
                    if (file >= 8) return FenResult.Invalid("$rankNo. sıra 8 kareden uzun.")
                    sq[r * 8 + file] = ch
                    file++
                    prevDigit = false
                } else {
                    return FenResult.Invalid("Geçersiz karakter: '$ch'.")
                }
                if (file > 8) return FenResult.Invalid("$rankNo. sıra 8 kareden uzun.")
            }
            if (file != 8) return FenResult.Invalid("$rankNo. sıra tam 8 kare etmiyor.")
        }

        // 2) Taş sayıları
        fun count(c: Char) = sq.count { it == c }
        if (count('K') != 1 || count('k') != 1) {
            return FenResult.Invalid("Her tarafın tam olarak bir şahı olmalı.")
        }
        for (white in listOf(true, false)) {
            fun n(c: Char) = count(if (white) c.uppercaseChar() else c)
            val surplus = n('p') + maxOf(0, n('q') - 1) + maxOf(0, n('r') - 2) +
                maxOf(0, n('b') - 2) + maxOf(0, n('n') - 2)
            if (n('p') > 8 || surplus > 8) {
                return FenResult.Invalid("${if (white) "Beyaz" else "Siyah"} için taş sayısı mümkün değil.")
            }
        }
        for (i in 0 until 8) {
            if (sq[i] == 'P' || sq[i] == 'p' || sq[56 + i] == 'P' || sq[56 + i] == 'p') {
                return FenResult.Invalid("1. veya 8. sırada piyon olamaz.")
            }
        }

        // 3) Sıra kimde
        val side = when (parts[1]) {
            "w" -> Side.WHITE
            "b" -> Side.BLACK
            else -> return FenResult.Invalid("Sıra alanı 'w' veya 'b' olmalı.")
        }

        // 4) Rok hakları
        val castlingRaw = parts[2]
        var castling = "-"
        if (castlingRaw != "-") {
            if (castlingRaw.any { it !in "KQkq" } || castlingRaw.toSet().size != castlingRaw.length) {
                return FenResult.Invalid("Rok alanı geçersiz.")
            }
            castling = "KQkq".filter { it in castlingRaw }
            for (c in castling) {
                val ok = when (c) {
                    'K' -> sq[60] == 'K' && sq[63] == 'R'
                    'Q' -> sq[60] == 'K' && sq[56] == 'R'
                    'k' -> sq[4] == 'k' && sq[7] == 'r'
                    else -> sq[4] == 'k' && sq[0] == 'r'
                }
                if (!ok) return FenResult.Invalid("Rok hakkı '$c' taşların konumuyla uyuşmuyor.")
            }
        }

        // 5) Geçerken alma karesi
        val ep = parts[3]
        if (ep != "-") {
            val target = squareIndex(ep)
            val wantRank = if (side == Side.WHITE) '6' else '3'
            if (target < 0 || ep[1] != wantRank) return FenResult.Invalid("Geçerken alma karesi geçersiz.")
            val f = target % 8
            val ok = if (side == Side.WHITE) {
                sq[3 * 8 + f] == 'p' && sq[2 * 8 + f] == Position.EMPTY && sq[1 * 8 + f] == Position.EMPTY
            } else {
                sq[4 * 8 + f] == 'P' && sq[5 * 8 + f] == Position.EMPTY && sq[6 * 8 + f] == Position.EMPTY
            }
            if (!ok) return FenResult.Invalid("Geçerken alma karesi taşların konumuyla uyuşmuyor.")
        }

        // 6) Sayaçlar
        val half = if (parts.size > 4) parts[4].toIntOrNull() else 0
        val full = if (parts.size > 5) parts[5].toIntOrNull() else 1
        if (half == null || half < 0) return FenResult.Invalid("Yarım hamle sayacı geçersiz.")
        if (full == null || full < 1) return FenResult.Invalid("Hamle numarası geçersiz.")

        // 7) Şah kuralları
        val wk = sq.indexOf('K')
        val bk = sq.indexOf('k')
        if (kotlin.math.abs(wk / 8 - bk / 8) <= 1 && kotlin.math.abs(wk % 8 - bk % 8) <= 1) {
            return FenResult.Invalid("İki şah yan yana olamaz.")
        }
        val waitingKing = if (side == Side.WHITE) bk else wk
        if (isAttacked(sq, waitingKing, side)) {
            return FenResult.Invalid("Sırası olmayan tarafın şahı tehdit altında; konum geçersiz.")
        }

        return FenResult.Valid(Position(sq, side, castling, ep, half, full))
    }

    /** [target] karesi, [by] tarafının bir taşı tarafından tehdit ediliyor mu? */
    fun isAttacked(squares: CharArray, target: Int, by: Side): Boolean {
        fun own(c: Char) = if (by == Side.WHITE) c.uppercaseChar() else c.lowercaseChar()
        val tr = target / 8
        val tf = target % 8

        val pawnRow = if (by == Side.WHITE) tr + 1 else tr - 1
        for (df in intArrayOf(-1, 1)) {
            val pf = tf + df
            if (pawnRow in 0..7 && pf in 0..7 && squares[pawnRow * 8 + pf] == own('p')) return true
        }
        for (m in KNIGHT_JUMPS) {
            val r = tr + m[0]
            val f = tf + m[1]
            if (r in 0..7 && f in 0..7 && squares[r * 8 + f] == own('n')) return true
        }
        for (dr in -1..1) for (df in -1..1) {
            if (dr == 0 && df == 0) continue
            val r = tr + dr
            val f = tf + df
            if (r in 0..7 && f in 0..7 && squares[r * 8 + f] == own('k')) return true
        }
        for (d in ROOK_DIRS) if (slides(squares, tr, tf, d, own('r'), own('q'))) return true
        for (d in BISHOP_DIRS) if (slides(squares, tr, tf, d, own('b'), own('q'))) return true
        return false
    }

    private fun slides(sq: CharArray, tr: Int, tf: Int, d: IntArray, a: Char, b: Char): Boolean {
        var r = tr + d[0]
        var f = tf + d[1]
        while (r in 0..7 && f in 0..7) {
            val c = sq[r * 8 + f]
            if (c != Position.EMPTY) return c == a || c == b
            r += d[0]
            f += d[1]
        }
        return false
    }
}
