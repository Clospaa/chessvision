package com.chessvision.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Palette {
    val Bg = Color(0xFF0B1220)          // koyu lacivert
    val Surface = Color(0xFF121B2E)
    val SurfaceHigh = Color(0xFF1A2640)
    val Blue = Color(0xFF2979FF)        // elektrik mavisi (vurgu)
    val Green = Color(0xFF22C55E)       // pozitif avantaj
    val Orange = Color(0xFFF59E0B)      // uyarı
    val Red = Color(0xFFEF4444)         // hata
    val Text = Color(0xFFE6EDF7)
    val TextDim = Color(0xFF94A3B8)
    val SquareLight = Color(0xFFDCE3EF)
    val SquareDark = Color(0xFF5B7BA6)
    val SquareLightHl = Color(0xFF9CC2FF)
    val SquareDarkHl = Color(0xFF2F6FE0)
}

@Composable
fun ChessVisionTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.Blue,
            onPrimary = Color.White,
            background = Palette.Bg,
            onBackground = Palette.Text,
            surface = Palette.Surface,
            onSurface = Palette.Text,
            surfaceVariant = Palette.SurfaceHigh,
            onSurfaceVariant = Palette.TextDim,
            error = Palette.Red,
        ),
        content = content,
    )
}
