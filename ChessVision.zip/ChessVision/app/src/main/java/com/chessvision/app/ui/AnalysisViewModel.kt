package com.chessvision.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.chessvision.app.chess.Fen
import com.chessvision.app.chess.FenResult
import com.chessvision.app.engine.AnalysisResult
import com.chessvision.app.engine.EngineException
import com.chessvision.app.engine.InvalidFenException
import com.chessvision.app.engine.PvLine
import com.chessvision.app.engine.StockfishEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

enum class EngineStatus { STARTING, READY, ERROR }

data class AnalysisUiState(
    val engineStatus: EngineStatus = EngineStatus.STARTING,
    val engineMessage: String? = null,
    val fenInput: String = Fen.START,
    val fenError: String? = null,
    val analyzing: Boolean = false,
    /** Analiz sürerken gelen son ara sonuç. */
    val live: PvLine? = null,
    /** Tamamlanan (veya durdurulan) analizin sonucu. */
    val result: AnalysisResult? = null,
    val analysisError: String? = null,
    val whiteAtBottom: Boolean = true,
    val moveTimeMs: Long = 3_000,
)

class AnalysisViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(AnalysisUiState())
    val state: StateFlow<AnalysisUiState> = _state.asStateFlow()

    @Volatile private var engine: StockfishEngine? = null

    init {
        startEngine()
    }

    private fun startEngine() {
        viewModelScope.launch(Dispatchers.IO) {
            val binary = File(getApplication<Application>().applicationInfo.nativeLibraryDir, "libstockfish.so")
            if (!binary.exists()) {
                _state.update {
                    it.copy(
                        engineStatus = EngineStatus.ERROR,
                        engineMessage = "Motor dosyası (libstockfish.so) uygulamada yok. " +
                            "Cihaz arm64 değilse bu sürüm çalışmaz; ya da derleme sırasında dosya eklenmemiş.",
                    )
                }
                return@launch
            }
            val threads = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(1, 4)
            val e = StockfishEngine(binary.absolutePath, threads = threads, hashMb = 32)
            try {
                e.start()
                engine = e
                _state.update { it.copy(engineStatus = EngineStatus.READY, engineMessage = null) }
            } catch (ex: EngineException) {
                e.close()
                _state.update { it.copy(engineStatus = EngineStatus.ERROR, engineMessage = ex.message) }
            }
        }
    }

    fun setFen(text: String) {
        if (_state.value.analyzing) return
        _state.update { it.copy(fenInput = text, fenError = null, result = null, live = null, analysisError = null) }
    }

    fun setMoveTime(ms: Long) = _state.update { it.copy(moveTimeMs = ms) }

    fun setWhiteAtBottom(value: Boolean) = _state.update { it.copy(whiteAtBottom = value) }

    fun analyze() {
        val st = _state.value
        if (st.analyzing) return
        val eng = engine ?: return
        val fen = st.fenInput
        val parsed = Fen.parse(fen)
        if (parsed is FenResult.Invalid) {
            _state.update { it.copy(fenError = parsed.reason, result = null, live = null) }
            return
        }
        _state.update {
            it.copy(analyzing = true, fenError = null, analysisError = null, live = null, result = null)
        }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val res = eng.analyze(fen, moveTimeMs = st.moveTimeMs) { line ->
                    _state.update { it.copy(live = line) }
                }
                _state.update { it.copy(analyzing = false, result = res) }
            } catch (e: InvalidFenException) {
                _state.update { it.copy(analyzing = false, fenError = e.message) }
            } catch (e: EngineException) {
                _state.update {
                    it.copy(
                        analyzing = false,
                        analysisError = "Motor hatası: ${e.message}",
                        engineStatus = if (eng.isAlive) it.engineStatus else EngineStatus.ERROR,
                        engineMessage = if (eng.isAlive) it.engineMessage else e.message,
                    )
                }
            } catch (e: Exception) {
                _state.update { it.copy(analyzing = false, analysisError = "Beklenmeyen hata: ${e.message}") }
            }
        }
    }

    fun stop() {
        engine?.stop()
    }

    override fun onCleared() {
        val e = engine
        engine = null
        if (e != null) Thread { e.close() }.start()
        super.onCleared()
    }
}
