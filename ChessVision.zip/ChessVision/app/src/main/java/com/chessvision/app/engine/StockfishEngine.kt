package com.chessvision.app.engine

import com.chessvision.app.chess.Fen
import com.chessvision.app.chess.FenResult
import com.chessvision.app.chess.Side
import java.io.File
import java.io.IOException
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class EngineException(message: String, cause: Throwable? = null) : Exception(message, cause)

/** FEN geçersiz: motor hiç çalıştırılmadı. */
class InvalidFenException(message: String) : Exception(message)

data class PvLine(
    val multiPv: Int,
    val depth: Int,
    val eval: Eval,
    val moves: List<String>,
    val nodes: Long?,
    val nps: Long?,
    val timeMs: Long?,
)

data class AnalysisResult(
    val fen: String,
    val sideToMove: Side,
    /** Konumda hamle yoksa (mat/pat) null. */
    val bestMove: String?,
    val ponder: String?,
    val lines: List<PvLine>,
    val stoppedEarly: Boolean,
    val elapsedMs: Long,
) {
    val depth: Int get() = lines.firstOrNull()?.depth ?: 0
}

/**
 * Stockfish'i ayrı bir süreç olarak çalıştırıp UCI ile konuşur.
 * Android'e bağımlı değildir; yalnızca motor dosyasının yolunu bilir.
 * [analyze] bloklayıcıdır: ana iş parçacığında ÇAĞIRMAYIN. [stop] her iş parçacığından çağrılabilir.
 */
class StockfishEngine(
    private val binaryPath: String,
    private val threads: Int = 1,
    private val hashMb: Int = 16,
) : AutoCloseable {

    private val lock = Any()        // aynı anda tek analiz
    private val writeLock = Any()   // motorun girişine yazma
    @Volatile private var process: Process? = null
    @Volatile private var queue = LinkedBlockingQueue<String>()
    @Volatile private var analyzing = false
    @Volatile private var stopRequested = false
    @Volatile private var closed = false

    val isAlive: Boolean get() = process?.isAlive == true

    fun start(timeoutMs: Long = 45_000) {
        synchronized(lock) {
            if (closed) throw EngineException("Motor kapatıldı.")
            if (process?.isAlive == true) return
            val file = File(binaryPath)
            if (!file.exists()) throw EngineException("Motor dosyası bulunamadı: $binaryPath")
            if (!file.canExecute()) throw EngineException("Motor dosyası çalıştırılabilir değil: $binaryPath")

            val p = try {
                ProcessBuilder(binaryPath).redirectErrorStream(true).start()
            } catch (e: IOException) {
                throw EngineException("Motor başlatılamadı: ${e.message}", e)
            }
            val q = LinkedBlockingQueue<String>()
            process = p
            queue = q
            thread(isDaemon = true, name = "uci-reader") {
                try {
                    p.inputStream.bufferedReader().forEachLine { q.put(it) }
                } catch (_: IOException) {
                    // süreç kapandı
                } finally {
                    q.put(EOF)
                }
            }
            try {
                send("uci")
                waitFor("uciok", timeoutMs)
                send("setoption name Threads value ${threads.coerceAtLeast(1)}")
                send("setoption name Hash value ${hashMb.coerceAtLeast(1)}")
                send("isready")
                waitFor("readyok", timeoutMs)
            } catch (e: EngineException) {
                p.destroyForcibly()
                process = null
                throw e
            }
        }
    }

    fun analyze(
        fen: String,
        depth: Int? = null,
        moveTimeMs: Long? = null,
        multiPv: Int = 1,
        maxWaitMs: Long = 120_000,
        onInfo: (PvLine) -> Unit = {},
    ): AnalysisResult {
        val position = when (val parsed = Fen.parse(fen)) {
            is FenResult.Invalid -> throw InvalidFenException(parsed.reason)
            is FenResult.Valid -> parsed.position
        }
        val normalizedFen = position.toFen()
        val side = position.sideToMove

        synchronized(lock) {
            start()
            val p = process ?: throw EngineException("Motor çalışmıyor.")
            val q = queue
            q.clear()
            stopRequested = false

            send("setoption name MultiPV value ${multiPv.coerceIn(1, 5)}")
            send("position fen $normalizedFen")
            send("isready")
            waitFor("readyok", 10_000)

            val go = buildString {
                append("go")
                if (depth != null) append(" depth ").append(depth.coerceAtLeast(1))
                if (moveTimeMs != null) append(" movetime ").append(moveTimeMs.coerceAtLeast(1))
                if (depth == null && moveTimeMs == null) append(" movetime 1000")
            }
            val startNs = System.nanoTime()
            analyzing = true
            val latest = sortedMapOf<Int, PvLine>()
            var best: BestMove? = null
            var forcedStop = false
            val softDeadline = startNs + maxWaitMs * 1_000_000
            var hardDeadline = Long.MAX_VALUE
            try {
                send(go)
                if (stopRequested) send("stop")  // stop(), "go"dan önce geldiyse

                while (best == null) {
                    val line = q.poll(200, TimeUnit.MILLISECONDS)
                    if (line == null) {
                        if (!p.isAlive) throw EngineException("Motor beklenmedik şekilde kapandı.")
                        val now = System.nanoTime()
                        if (!forcedStop && now > softDeadline) {
                            forcedStop = true
                            hardDeadline = now + 5_000_000_000L
                            send("stop")
                        }
                        if (now > hardDeadline) {
                            p.destroyForcibly()
                            throw EngineException("Motor durdurma komutuna yanıt vermedi.")
                        }
                        continue
                    }
                    if (line == EOF) throw EngineException("Motor beklenmedik şekilde kapandı.")

                    val bm = UciParser.parseBestMove(line)
                    if (bm != null) { best = bm; continue }

                    val info = UciParser.parseInfo(line) ?: continue
                    if (!info.exact) continue
                    val pl = PvLine(
                        multiPv = info.multiPv,
                        depth = info.depth,
                        eval = info.score.toWhiteEval(side),
                        moves = info.pv,
                        nodes = info.nodes,
                        nps = info.nps,
                        timeMs = info.timeMs,
                    )
                    latest[info.multiPv] = pl
                    runCatching { onInfo(pl) }
                }
            } finally {
                analyzing = false
            }

            val elapsedMs = (System.nanoTime() - startNs) / 1_000_000
            return AnalysisResult(
                fen = normalizedFen,
                sideToMove = side,
                bestMove = best.move,
                ponder = best.ponder,
                lines = latest.values.toList(),
                stoppedEarly = stopRequested || forcedStop,
                elapsedMs = elapsedMs,
            )
        }
    }

    /** Çalışan analizi durdurur; [analyze] o ana kadarki en iyi sonuçla döner. */
    fun stop() {
        stopRequested = true
        if (analyzing) {
            try { send("stop") } catch (_: EngineException) { }
        }
    }

    override fun close() {
        if (closed) return
        closed = true
        val p = process ?: return
        try {
            send("stop")
            send("quit")
        } catch (_: EngineException) {
        }
        try {
            if (!p.waitFor(2, TimeUnit.SECONDS)) p.destroyForcibly()
        } catch (_: InterruptedException) {
            p.destroyForcibly()
        }
        process = null
    }

    private fun send(command: String) {
        val p = process ?: throw EngineException("Motor çalışmıyor.")
        synchronized(writeLock) {
            try {
                val out = p.outputStream
                out.write((command + "\n").toByteArray(Charsets.UTF_8))
                out.flush()
            } catch (e: IOException) {
                throw EngineException("Motora komut gönderilemedi: ${e.message}", e)
            }
        }
    }

    private fun waitFor(token: String, timeoutMs: Long) {
        val deadline = System.nanoTime() + timeoutMs * 1_000_000
        val q = queue
        while (true) {
            val remainingMs = (deadline - System.nanoTime()) / 1_000_000
            if (remainingMs <= 0) throw EngineException("Motor '$token' yanıtını zamanında vermedi.")
            val line = q.poll(minOf(remainingMs, 200), TimeUnit.MILLISECONDS) ?: continue
            if (line == EOF) throw EngineException("Motor beklenmedik şekilde kapandı.")
            if (line.trim() == token) return
        }
    }

    private companion object {
        const val EOF = "\u0000EOF"
    }
}
