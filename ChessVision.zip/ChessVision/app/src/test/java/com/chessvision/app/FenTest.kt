package com.chessvision.app

import com.chessvision.app.chess.Fen
import com.chessvision.app.chess.FenResult
import com.chessvision.app.chess.Side
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FenTest {
    private fun invalid(fen: String) {
        val r = Fen.parse(fen)
        assertTrue("Geçersiz olmalıydı: $fen -> $r", r is FenResult.Invalid)
    }

    @Test
    fun startPositionIsValidAndRoundTrips() {
        val r = Fen.parse(Fen.START)
        assertTrue(r is FenResult.Valid)
        val p = (r as FenResult.Valid).position
        assertEquals(Fen.START, p.toFen())
        assertEquals(Side.WHITE, p.sideToMove)
        assertEquals('r', p.squares[0])   // a8
        assertEquals('K', p.squares[60])  // e1
    }

    @Test
    fun fourFieldFenGetsDefaultCounters() {
        val r = Fen.parse("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq -")
        assertEquals(Fen.START, ((r as FenResult.Valid).position).toFen())
    }

    @Test
    fun validEnPassantAndPromotedPieces() {
        assertTrue(Fen.parse("rnbqkbnr/ppp1pppp/8/3pP3/8/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 3") is FenResult.Valid)
        assertTrue(Fen.parse("4k3/8/8/8/8/8/8/QQ2K3 w - - 0 1") is FenResult.Valid)  // iki vezir: terfi
    }

    @Test
    fun rejectsBrokenSyntax() {
        invalid("")
        invalid("not a fen")
        invalid("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP w KQkq - 0 1")                 // 7 sıra
        invalid("rnbqkbnr/pppppppp/9/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")        // 9
        invalid("rnbqkbnr/pppppppp/44/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")       // art arda rakam
        invalid("rnbqkbnr/pppppppp/7/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")        // 7 kare
        invalid("rnbqkbnx/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")        // x
        invalid("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR x KQkq - 0 1")        // sıra alanı
        invalid("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - -1 1")       // sayaç
    }

    @Test
    fun rejectsImpossiblePositions() {
        invalid("4k3/8/8/8/8/8/8/4K2K w - - 0 1")                  // iki beyaz şah
        invalid("8/8/8/8/8/8/8/4K3 w - - 0 1")                     // siyah şah yok
        invalid("P3k3/8/8/8/8/8/8/4K3 w - - 0 1")                  // 8. sırada piyon
        invalid("4k3/8/8/8/8/8/8/3kK3 w - - 0 1")                  // yan yana şahlar
        invalid("4k3/8/8/8/8/8/8/R3K3 w KQ - 0 1")                 // K hakkı ama h1'de kale yok
        invalid("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq e3 0 1") // yanlış ep
        invalid("4k3/pppppppp/p7/8/8/8/8/4K3 w - - 0 1")           // 9 siyah piyon
    }

    @Test
    fun rejectsPositionWhereWaitingSideIsInCheck() {
        // Sıra beyazda ama siyah şah e8, beyaz kale e1 ile tehdit altında -> imkânsız konum
        invalid("4k3/8/8/8/8/8/8/4RK2 w - - 0 1")
        // Aynı konum sıra siyahtayken geçerlidir (siyah şah çekiyor)
        assertTrue(Fen.parse("4k3/8/8/8/8/8/8/4RK2 b - - 0 1") is FenResult.Valid)
    }

    @Test
    fun squareNames() {
        assertEquals(0, Fen.squareIndex("a8"))
        assertEquals(63, Fen.squareIndex("h1"))
        assertEquals(60, Fen.squareIndex("e1"))
        assertEquals(-1, Fen.squareIndex("i9"))
        assertEquals("e4", Fen.squareName(Fen.squareIndex("e4")))
    }
}
