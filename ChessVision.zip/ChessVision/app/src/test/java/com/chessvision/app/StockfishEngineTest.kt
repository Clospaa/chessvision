package com.chessvision.app

import com.chessvision.app.chess.Side
import com.chessvision.app.engine.EngineException
import com.chessvision.app.engine.InvalidFenException
import com.chessvision.app.engine.StockfishEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import kotlin.concurrent.thread

/**
 * Gerçek motor testleri: STOCKFISH_BIN ortam değişkeni, bilgisayarda çalışan bir
 * Stockfish dosyasını (ör. Linux x86-64 sürümü) göstermelidir. Tanımlı değilse bu testler
 * atlanır (başarılı sayılır); Android cihazdaki motor ayrıca cihazda denenmelidir.
 */
class StockfishEngineTest {
    private val bin: String? = System.getenv("STOCKFISH_BIN")?.takeIf { it.isNotBlank() }

    private fun engine() = StockfishEngine(bin!!, threads = 1, hashMb = 16)

    @Test
    fun missingBinaryGivesClearError() {
        val e = StockfishEngine("/yok/boyle/bir/dosya")
        try {
            e.start()
            fail("EngineException bekleniyordu")
        } catch (ex: EngineException) {
            assertTrue(ex.message!!.contains("bulunamadı"))
        }
    }

    @Test
    fun invalidFenIsRejectedWithoutStartingEngine() {
        val e = StockfishEngine("/yok/boyle/bir/dosya")
        try {
            e.analyze("bu bir fen degil", depth = 5)
            fail("InvalidFenException bekleniyordu")
        } catch (ex: InvalidFenException) {
            assertFalse(e.isAlive)  // motor hiç başlatılmadı
        }
    }

    @Test
    fun startsAndAnalyzesStartPosition() {
        if (bin == null) return
        engine().use { e ->
            e.start()
            assertTrue(e.isAlive)
            val r = e.analyze("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", depth = 8)
            assertNotNull(r.bestMove)
            assertTrue(r.depth >= 8)
            assertEquals(Side.WHITE, r.sideToMove)
            assertTrue(r.lines.first().moves.isNotEmpty())
            assertNull(r.lines.first().eval.mateIn)
        }
        // kapatıldıktan sonra süreç kalmamalı
    }

    @Test
    fun findsMateInOneForWhite() {
        if (bin == null) return
        engine().use { e ->
            val r = e.analyze("6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1", depth = 6)
            assertEquals("a1a8", r.bestMove)
            assertEquals(1, r.lines.first().eval.mateIn)
            assertEquals("+M1", r.lines.first().eval.label())
        }
    }

    @Test
    fun blackPerspectiveIsConvertedCorrectly() {
        if (bin == null) return
        engine().use { e ->
            // Sıra siyahta, siyah Ra1# oynayıp mat ediyor: beyaz açısından NEGATİF mat
            val r = e.analyze("r5k1/8/8/8/8/8/5PPP/6K1 b - - 0 1", depth = 6)
            assertEquals("a8a1", r.bestMove)
            assertEquals(-1, r.lines.first().eval.mateIn)
            assertEquals("-M1", r.lines.first().eval.label())
            assertEquals(0f, r.lines.first().eval.whiteFraction(), 0.0001f)
        }
    }

    @Test
    fun checkmatedPositionHasNoBestMove() {
        if (bin == null) return
        engine().use { e ->
            val r = e.analyze("R5k1/5ppp/8/8/8/8/8/6K1 b - - 0 1", depth = 4)
            assertNull(r.bestMove)
            assertEquals(Side.BLACK, r.lines.first().eval.checkmatedSide)
        }
    }

    @Test
    fun stopEndsAnalysisEarlyAndEngineStaysUsable() {
        if (bin == null) return
        engine().use { e ->
            e.start()
            var result: com.chessvision.app.engine.AnalysisResult? = null
            val t = thread {
                result = e.analyze(
                    "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
                    moveTimeMs = 60_000,
                )
            }
            Thread.sleep(700)
            val t0 = System.nanoTime()
            e.stop()
            t.join(5_000)
            val waitedMs = (System.nanoTime() - t0) / 1_000_000
            assertFalse("Analiz durmadı", t.isAlive)
            assertTrue("Durdurma çok yavaş: $waitedMs ms", waitedMs < 4_000)
            assertTrue(result!!.stoppedEarly)
            assertNotNull(result!!.bestMove)
            // durdurduktan sonra yeni analiz çalışabilmeli
            val again = e.analyze("6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1", depth = 4)
            assertEquals("a1a8", again.bestMove)
        }
    }

    @Test
    fun closeTerminatesEngine() {
        if (bin == null) return
        val e = engine()
        e.start()
        assertTrue(e.isAlive)
        e.close()
        assertFalse(e.isAlive)
    }
}
