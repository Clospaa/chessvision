package com.chessvision.app

import com.chessvision.app.chess.Side
import com.chessvision.app.engine.Score
import com.chessvision.app.engine.UciParser
import com.chessvision.app.engine.toWhiteEval
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UciParserTest {
    @Test
    fun parsesRealStockfishInfoLine() {
        val l = UciParser.parseInfo(
            "info depth 8 seldepth 11 multipv 1 score cp 25 nodes 2712 nps 542400 hashfull 0 tbhits 0 time 5 pv e2e4 c7c5 g1f3 b8c6 b1c3 a7a6 d2d4 c5d4 f3d4"
        )
        assertNotNull(l)
        l!!
        assertEquals(8, l.depth)
        assertEquals(1, l.multiPv)
        assertEquals(Score.Cp(25), l.score)
        assertTrue(l.exact)
        assertEquals(5L, l.timeMs)
        assertEquals(2712L, l.nodes)
        assertEquals(9, l.pv.size)
        assertEquals("e2e4", l.pv[0])
    }

    @Test
    fun parsesMateAndBounds() {
        val m = UciParser.parseInfo("info depth 3 seldepth 2 multipv 1 score mate 1 nodes 40 nps 1000 time 1 pv a1a8")!!
        assertEquals(Score.Mate(1), m.score)
        val b = UciParser.parseInfo("info depth 12 multipv 1 score cp 40 lowerbound nodes 9 pv e2e4")!!
        assertEquals(false, b.exact)
        assertEquals(Score.Cp(40), b.score)
        val terminal = UciParser.parseInfo("info depth 0 score mate 0")!!
        assertEquals(Score.Mate(0), terminal.score)
        assertTrue(terminal.pv.isEmpty())
    }

    @Test
    fun ignoresNonScoreLines() {
        assertNull(UciParser.parseInfo("info string NNUE evaluation using something.nnue"))
        assertNull(UciParser.parseInfo("info depth 5 currmove e2e4 currmovenumber 1"))
        assertNull(UciParser.parseInfo("readyok"))
        assertNull(UciParser.parseInfo("bestmove e2e4"))
    }

    @Test
    fun parsesBestMove() {
        val a = UciParser.parseBestMove("bestmove e2e4 ponder c7c5")!!
        assertEquals("e2e4", a.move)
        assertEquals("c7c5", a.ponder)
        val b = UciParser.parseBestMove("bestmove e7e8q")!!
        assertEquals("e7e8q", b.move)
        assertNull(b.ponder)
        assertNull(UciParser.parseBestMove("bestmove (none)")!!.move)
        assertNull(UciParser.parseBestMove("info depth 1"))
    }

    @Test
    fun scoreIsConvertedToWhitePerspective() {
        // Sıra beyazda: puan olduğu gibi
        assertEquals(50, Score.Cp(50).toWhiteEval(Side.WHITE).centipawns)
        // Sıra siyahta +50 (siyah öne) = beyaz açısından -50
        assertEquals(-50, Score.Cp(50).toWhiteEval(Side.BLACK).centipawns)
        // Mat: sıra siyahta "mate 2" siyah mat ediyor = beyaz açısından -2
        assertEquals(-2, Score.Mate(2).toWhiteEval(Side.BLACK).mateIn)
        assertEquals(3, Score.Mate(-3).toWhiteEval(Side.BLACK).mateIn)
        assertNull(Score.Mate(2).toWhiteEval(Side.WHITE).centipawns)  // mat piyon puanı gibi gösterilmez
    }

    @Test
    fun evalLabelsAndBar() {
        assertEquals("+0.25", Score.Cp(25).toWhiteEval(Side.WHITE).label())
        assertEquals("-1.30", Score.Cp(130).toWhiteEval(Side.BLACK).label())
        assertEquals("+M3", Score.Mate(3).toWhiteEval(Side.WHITE).label())
        assertEquals("-M3", Score.Mate(3).toWhiteEval(Side.BLACK).label())
        val checkmated = Score.Mate(0).toWhiteEval(Side.BLACK)
        assertEquals(Side.BLACK, checkmated.checkmatedSide)
        assertEquals("Mat", checkmated.label())
        assertEquals(1f, checkmated.whiteFraction(), 0.0001f)   // siyah mat -> bar tamamen beyaz
        assertEquals(0.5f, Score.Cp(0).toWhiteEval(Side.WHITE).whiteFraction(), 0.0001f)
        assertTrue(Score.Cp(300).toWhiteEval(Side.WHITE).whiteFraction() > 0.6f)
    }
}
