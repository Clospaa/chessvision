# Lisans bildirimi

- **Stockfish** (GNU GPL v3) uygulamaya `libstockfish.so` adıyla eklenir. Kaynak kodu ve lisans metni:
  https://github.com/official-stockfish/Stockfish — lisans metni derleme sırasında
  `assets/licenses/stockfish-COPYING.txt` olarak APK'ya konur.
  Stockfish GPL v3 olduğu için bu uygulamayı dağıtırsanız uygulamanın kaynak kodunu da GPL v3 ile
  alıcılara sunmanız gerekir. Yalnızca kendi telefonunuzda kullanıyorsanız bu yükümlülük doğmaz.
- **AndroidX / Jetpack Compose / Kotlin coroutines**: Apache License 2.0.
- Bu projenin kendi kodu: GPL-3.0-or-later (Stockfish ile birlikte dağıtıldığı için).
